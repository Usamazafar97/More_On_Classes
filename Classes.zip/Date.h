/*
 * Date.h
 *
 *  Created on: Mar 23, 2018
 *      Author: DELL
 */

#ifndef DATE_H_
#define DATE_H_
#include<iostream>
using namespace std;
class Date {
	int year;
	int month;
	int day;

public:
	Date(int year, int month, int day);
	void addDays(const int &days);
	bool isLeapYear()const;
	int getDay()const;
	int getMonth()const;
	int getYear()const;
	int daysTo(const Date & other);
	string toString();
	virtual ~Date();
};

#endif /* DATE_H_ */
