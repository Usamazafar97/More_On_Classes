/*
 * Point.cpp
 *
 *  Created on: Mar 23, 2018
 *      Author: DELL
 */

#include "Point.h"

Point::Point()
{
	// TODO Auto-generated constructor stub
				x = y = 0;
}
Point::Point(int x1, int y1)
	{
		x = x1;
		y = y1;
	}
int Point::getX() const
	{
		return x;
	}
void Point::setX(int x)
	{
		this->x = x;
	}
int Point::getY( )const
	{
		return y;
	}
void Point::setY(int y)
	{
		this->y = y;
	}
Point::~Point()
{
	// TODO Auto-generated destructor stub
	cout << "Destructor called";
}

