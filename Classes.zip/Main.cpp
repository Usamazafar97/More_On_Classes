//============================================================================
// Name        : LabTask8.cpp
// Author      : Usama Zafar
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C, Ansi-style
//============================================================================

#include <stdio.h>
#include <stdlib.h>
#include "Line.h"
#include "Point.h"
#include "Date.h"
#include "ParkingGarage.h"
#include "Car.h"
#include "Holiday.h"
#include "Section.h"
#include "Student.h"

int main(void) {
	puts("!!!Hello World!!!");
	return EXIT_SUCCESS;
}
