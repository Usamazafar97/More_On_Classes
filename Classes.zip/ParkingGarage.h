/*
 * ParkingGarage.h
 *
 *  Created on: Mar 22, 2018
 *      Author: DELL
 */

#ifndef PARKINGGARAGE_H_
#define PARKINGGARAGE_H_
#include "Car.h"
#include<iostream>
using namespace std;
class ParkingGarage {
	const int capacity;
	int noOfOccupied;
	Car *carPointer;
	double amountCollected;
public:
	 ParkingGarage();
	 ParkingGarage(int c);
	 int getRemainingCapacity() const;
	 double getAmountCollected() const;
	 bool IsFull()const;
	 bool ParkCar(const string &regnNumber,int entryTime );
	 double RemoveCar(const string &regnNumber,int exitTime );
	virtual ~ParkingGarage();
};

#endif /* PARKINGGARAGE_H_ */
