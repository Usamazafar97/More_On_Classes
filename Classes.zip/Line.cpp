/*
 * Line.cpp
 *
 *  Created on: Mar 23, 2018
 *      Author: DELL
 */

#include "Line.h"

Line::Line() {
	// TODO Auto-generated constructor stub

}
Point Line::getP1() const
{
	return P1;
}
Point Line::getP2() const
{
	return P2;
}
Line::Line(const Point &p1, const Point &p2)
{
	P1 = p1;
	P2 = p2;
}
Line::Line(int x1, int y1, int x2, int y2)
{
	P1.setX(x1);
	P1.setY(y1);
	P2.setX(x2);
	P2.setY(y2);
}
double Line::getSlope() const
{
	return ((P2.getY() - P1.getY()) / (P2.getX() - P1.getX()));
}
Line::~Line() {
	// TODO Auto-generated destructor stub
}

