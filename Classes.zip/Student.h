/*
 * Student.h
 *
 *  Created on: Mar 23, 2018
 *      Author: DELL
 */

#ifndef STUDENT_H_
#define STUDENT_H_

#include<iostream>
using namespace std;

class Student {
	int rollNo;
	string name;
	string address;
	int batch;
public:
	Student();
	Student(int r, const string &n, const string &ad, int b);
	 bool setRollNo(int r);
	 int getRollNo() const;
	 bool setName(const string &n);
	 string getName()const;
	 bool setAddress(const string& ad);
	 string getAddress() const;
	 bool setBatch(int b);
	 int getBatch()const;
	virtual ~Student();
};

#endif /* STUDENT_H_ */
