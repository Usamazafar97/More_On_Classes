/*
 * Date.cpp
 *
 *  Created on: Mar 23, 2018
 *      Author: DELL
 */

#include "Date.h"

Date::Date(int year, int month, int day): year(1),month(1),day(1){
	// TODO Auto-generated constructor stub
}
void Date::addDays(const int &days)
{
	    int Tempday=day;
	    Tempday += days;
	    if(isLeapYear())
	    {
			const int month_days[ ] = {0, 31, 29, 31, 30, 31, 30 , 31, 31 , 30, 31, 30, 31};
			if (Tempday > month_days[month]) // if above the last day of the month
			   {
					int Temp2 =month_days[month]-day;
					int Temp3 =days - Temp2;
					day = Temp3;

					month = month % 12 + 1;
			   }
	    }
	    else
	    {
	    	const int month_days[ ] = {0, 31, 28, 31, 30, 31, 30 , 31, 31 , 30, 31, 30, 31};
			if (Tempday > month_days[month]) // if above the last day of the month
			   {
					int Temp2 =month_days[month]-day;
					int Temp3 =days - Temp2;
					day = Temp3;

					month = month % 12 + 1;
			   }
	    }

//	if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8 ||month == 10 || month==12)
//	{
//		if()
//		{
//
//		}
//	}
//	else
//	{
//
//	}
}
int Date::getDay()const
{
	return day;
}
int Date::getMonth()const
{
	return month;
}
int Date::getYear()const
{
	return year;
}
bool Date::isLeapYear()const
{
	if( (year%400==0 || year%100!=0) &&(year%4==0))
		return true;
		else
			return false;

}
int Date::daysTo(const Date & other)
{
	int TempDay=0;
	int TempMonth=0;
	int TempYear=0;int TotalDays=0;
	if(other.day > getDay())
		TempDay=other.day-getDay();

	else
		TempDay=getDay()-other.day;
	if(other.month > getMonth())
		TempMonth=other.month-getMonth();

	else
		TempMonth=getMonth()-other.month;
	if(other.year > getYear())
		TempYear=other.year-getYear();

		else
			TempYear=getYear()-other.year;

	if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8 ||month == 10 || month==12)
	{
		 TotalDays = (TempDay*31) + (TempMonth*12) + (TempYear*365);
	}
	else
	{
		if(month==2)
			 TotalDays = (TempDay*28) + (TempMonth*12) + (TempYear*365);
		else
			 TotalDays = (TempDay*30) + (TempMonth*12) + (TempYear*365);
	}
	return TotalDays;
}
string Date::toString()
{
	 string StringToReturn;
	 int Temp=0;
	 int index=0;
	 int length=10;//because length is no more than 10 digits
	 for(;Temp!=0;++index)//for year
	 {
		 Temp=year/10;
		 StringToReturn[index]=Temp;
	 }
	 StringToReturn[index]='//';
	 index++;
	 Temp=0;
	 for(;Temp!=0;++index)//for year
	 {
		 Temp=month/10;
		 StringToReturn[index]=Temp;
	 }
	 StringToReturn[index]='//';
	 index++;
	 	 Temp=0;
	 	 for(;Temp!=0;++index)//for year
	 	 {
	 		 Temp=day/10;
	 		StringToReturn[index]=Temp;
	 	 }
	 return StringToReturn;
}
Date::~Date() {
	// TODO Auto-generated destructor stub
}

