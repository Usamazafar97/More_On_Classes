/*
 * Point.h
 *
 *  Created on: Mar 23, 2018
 *      Author: DELL
 */

#ifndef POINT_H_
#define POINT_H_
#include<iostream>
using namespace std;
class Point {

		int x;
		int y;
public:
	Point();
	Point(int x1, int y1);
	int getX() const;
	void setX(int x);
	int getY() const;
	void setY(int y);
	virtual ~Point();
};

#endif /* POINT_H_ */
