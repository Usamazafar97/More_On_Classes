/*
 * Holiday.h
 *
 *  Created on: Mar 22, 2018
 *      Author: DELL
 */

#ifndef HOLIDAY_H_
#define HOLIDAY_H_

#include<cstring>
#include<iostream>
using namespace std;
class Holiday {
	string name;
	int day;
	string month;

public:
	Holiday();

	Holiday(const string &n, int d, const string &m);

	 bool setName(const string &s);
	 string getName() const;
	 bool setDay(int u);
	 int getDay() const;
	 bool setMonth(const string &p);
	 string getMonth() const;

	virtual ~Holiday();

};
bool inSameMonth (const Holiday &a, const Holiday &b);
double avgDate(Holiday arr[], int size);
#endif /* HOLIDAY_H_ */
