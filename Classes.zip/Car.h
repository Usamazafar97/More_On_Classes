/*
 * Car.h
 *
 *  Created on: Mar 22, 2018
 *      Author: DELL
 */

#ifndef CAR_H_
#define CAR_H_

#include<iostream>
using namespace std;

class Car {
	string regNo;
	int entryTime;
	int exiteTime;
public:
	Car();
	virtual ~Car();

	int getEntryTime() const {
		return entryTime;
	}

	void setEntryTime(int entryTime) {
		this->entryTime = entryTime;
	}

	int getExiteTime() const {
		return exiteTime;
	}

	void setExiteTime(int exiteTime) {
		this->exiteTime = exiteTime;
	}

	const string& getRegNo() const {
		return regNo;
	}

	void setRegNo(const string& regNo) {
		this->regNo = regNo;
	}
};

#endif /* CAR_H_ */
