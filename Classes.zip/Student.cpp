/*
 * Student.cpp
 *
 *  Created on: Mar 23, 2018
 *      Author: DELL
 */

#include "Student.h"

Student::Student() {
	// TODO Auto-generated constructor stub
	 rollNo=0;
	 name="";
	 address="";
	 batch=0;
}
Student::Student(int r, const string &n, const string &ad, int b):rollNo(r),name(n),address(ad),batch(b)
{}
 bool Student::setRollNo(int r)
 {
	 if(r>0)
	 {
		 rollNo=r;
		 return true;
	 }
	 else
		 return false;
 }
 int Student::getRollNo() const
 {
	 return rollNo;
 }
 bool Student::setName(const string &n)
 {
	 int count=0;
	 for(int i=0;n[i]!='\0';i++)
	 {
		 count++;
	 }
	 if(count >50)
	 {
		 name=n;
	 }
	 else
		 return false;
 }
 string Student::getName()const
 {
	 return name;
 }
 bool Student::setAddress(const string& ad)
 {
	 int count=0;
	 for(int i=0;ad[i]!='\0';i++)
	 {
		 count++;
	 }
	 if(count >90)
	 {
		 address=ad;
	 }
	 else
		 return false;
 }
 string Student::getAddress() const
 {
	 return address;
 }
 bool Student::setBatch(int b)
 {
	 if(b>0)
	 {
		 batch=b;
		 return true;
	 }
	 else
		 return false;
 }
 int Student::getBatch()const
 {
	 return batch;
 }
Student::~Student() {
	// TODO Auto-generated destructor stub
}

