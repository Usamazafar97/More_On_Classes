/*
 * Section.cpp
 *
 *  Created on: Mar 23, 2018
 *      Author: DELL
 */

#include "Section.h"

Section::Section():sectionName(''),studentPtr(NULL),sectionStrength(0),currentStudent(0) {
	// TODO Auto-generated constructor stub
}
Section::Section(int s , char name):sectionName(name),sectionStrength(s)
{
	studentPtr=new Student[s];
	currentStudent=0;

}
 bool Section::setSectionName(const string &n)
 {
	 int count=0;
	 for(int i=0;n[i]!='\0';i++)
	 {
		 count++;
	 }
	 if(count <50)
	 {
		 sectionName=n;
		 return true;
	 }
	 else
		 return false;
 }
 string Section::getSectionName()const
 {
	 return sectionName;
 }
 int Section::getcurrentStudent() const
 {
	 return currentStudent;
 }
void Section::setCurrentStudent(int currentStudent) {
	this->currentStudent = currentStudent;
}

const int Section::getSectionStrength() const {
	return sectionStrength;
}

const Student*& Section::getStudentPtr() const {
	return studentPtr;
}

void Section::setStudentPtr(const Student*& studentPtr) {
	this->studentPtr = studentPtr;
}
bool Section::addStudent(int r, const string &n, const string &ad, int b)
{
	if(currentStudent < sectionStrength)
	{
		studentPtr[currentStudent].setRollNo(r);
		studentPtr[currentStudent].setName(n);
		studentPtr[currentStudent].setAddress(ad);
		studentPtr[currentStudent].setBatch(b);
		currentStudent++;
		return true;
	}
	else
	{
		return false;
	}
}
bool Section::deleteStudent()
{
	if(currentStudent !=0)
		{
	studentPtr[currentStudent].setRollNo(0);
	studentPtr[currentStudent].setName("");
	studentPtr[currentStudent].setAddress("");
	studentPtr[currentStudent].setBatch(0);
	currentStudent--;
	return true;
		}
	return false;
}

Section::~Section() {
	// TODO Auto-generated destructor stub
}

