/*
 * Car.cpp
 *
 *  Created on: Mar 22, 2018
 *      Author: DELL
 */

#include "Car.h"

Car::Car() {
	// TODO Auto-generated constructor stub
		regNo="";
		entryTime=0;
		exiteTime=0;
}
int Car::getEntryTime() const
{
		return entryTime;
}

void Car::setEntryTime(int entryTime)
{
	if(entryTime > 0 && entryTime < 23)
	{
		this->entryTime = entryTime;
	}

}

int Car::getExiteTime() const {
	return exiteTime;
}

void Car::setExiteTime(int exiteTime)
{
	if(exiteTime > 0 && exiteTime < 23)
		{
			if(this->exiteTime < entryTime)
			{
				this->exiteTime = exiteTime;
			}
		}
}

const string& Car::getRegNo() const
{
	return regNo;
}

void Car::setRegNo(const string& regNo)
{
		this->regNo = regNo;
}
Car::~Car() {
	// TODO Auto-generated destructor stub
}

