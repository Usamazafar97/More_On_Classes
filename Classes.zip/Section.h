/*
 * Section.h
 *
 *  Created on: Mar 23, 2018
 *      Author: DELL
 */

#ifndef SECTION_H_
#define SECTION_H_
#include "Student.h"

#include<iostream>
using namespace std;

class Section
{
	char sectionName;
	Student *studentPtr;
	const int sectionStrength;
	int currentStudent;
public:

	Section();
	Section (int s , char name);
	 bool setSectionName(const string &n);
	 string getSectionName()const;
	 int getcurrentStudent() const;
	 void setCurrentStudent(int currentStudent);
	 const int getSectionStrength() const;
	 const Student*& getStudentPtr() const;
	 void setStudentPtr(const Student*& studentPtr);
	 bool addStudent(int r, const string &n, const string &ad, int );
	 bool deleteStudent();
	 string SearchStudent(int r);
	 virtual ~Section();
};

#endif /* SECTION_H_ */
