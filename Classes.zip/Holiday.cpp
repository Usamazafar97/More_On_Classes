/*
 * Holiday.cpp
 *
 *  Created on: Mar 22, 2018
 *      Author: DELL
 */

#include "Holiday.h"

Holiday::Holiday():name(""),day(0),month("")
{
	// TODO Auto-generated constructor stub
}
Holiday::Holiday(const string &n, int d, const string &m):name(n),day( d),month(m)
{}
 bool Holiday::setName(const string &s)
 {
	 int length=0;
	 for(int i=0;s[i] != '\0';i++)
	 {
		 length++;
	 }
	 if(length>50)
	 {
		 name = s;
	 }
	 else
	 return false;
 }
 string Holiday::getName() const
 {
	 return name;
 }
 bool Holiday::setDay(int u)
 {
	 if(u>0)
	 {
		 day=u;
		 return true;
	 }
	 else
	 return false;
 }
 int Holiday::getDay() const
 {
	 return day;
 }
 bool Holiday::setMonth(const string &p)
 {
	 int length=0;
	 	 for(int i=0;p[i] != '\0';i++)
	 	 {
	 		 length++;
	 	 }
	 	 if(length>10)
	 	 {
	 		month = p;
	 	 }
	 	 else
	 	 return false;
 }
 string Holiday::getMonth() const
 {
	 return month;
 }
 bool inSameMonth (const Holiday &a, const Holiday &b)
 {
	 if(a.getMonth() == b.getMonth())
	 {
		 return true;
	 }
	 return false;
 }
 double avgDate(Holiday arr[], int size)
 {
	 double Average=0;
	 double sum=0;
	 for(int i=0;i<size;i++)
	 {
		 sum+=arr[i].getDay();
	 }
	 Average=sum/size;
	 return Average;
 }
Holiday::~Holiday()
{
	// TODO Auto-generated destructor stub
}

