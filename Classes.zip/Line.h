/*
 * Line.h
 *
 *  Created on: Mar 23, 2018
 *      Author: DELL
 */

#ifndef LINE_H_
#define LINE_H_
#include "Point.h"
#include<iostream>
using namespace std;
class Line
{
	Point P1, P2;
public:
Line();
Point getP1() const;
Point getP2() const;
Line(const Point &p1, const Point &p2);
Line(int x1, int y1, int x2, int y2);
double getSlope() const;
	virtual ~Line();
};

#endif /* LINE_H_ */
