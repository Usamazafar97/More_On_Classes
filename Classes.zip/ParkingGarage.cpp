/*
 * ParkingGarage.cpp
 *
 *  Created on: Mar 22, 2018
 *      Author: DELL
 */

#include "ParkingGarage.h"

ParkingGarage::ParkingGarage():capacity(5),noOfOccupied(0),amountCollected(0),carPointer(new Car[5])
{
	// TODO Auto-generated constructor stub
}
ParkingGarage::ParkingGarage(int c):capacity(c),noOfOccupied(0),amountCollected(0),carPointer(new Car[c])
{}
ParkingGarage::~ParkingGarage()
{
	// TODO Auto-generated destructor stub
}

 int ParkingGarage::getRemainingCapacity() const
 {
	 return capacity-noOfOccupied;
 }
 double ParkingGarage::getAmountCollected() const
 {
		 return amountCollected;
 }
 bool ParkingGarage::IsFull()const
 {
	 if(noOfOccupied > capacity)
	 {
		 return false;
	 }
	 else
		 return true;
 }
 bool ParkingGarage::ParkCar(const string &regnNumber,int entryTime )
 {
	 if(!IsFull())
	 {
	 	 Car temp;
	 	 temp.setRegNo(regnNumber);
	 	 temp.setEntryTime(entryTime);
		 carPointer[capacity] = temp;
		 noOfOccupied++;
		 return true;
	 }
	 else
		 return false;
 }
 double ParkingGarage::RemoveCar(const string &regnNumber,int exitTime )
 {

	 Car temp;
	 for(int i=0;i<capacity;i++)
	 {
		string  tempForRegistration = carPointer[i].getRegNo();
		 if(regnNumber == tempForRegistration)
		 {
			 int HoursCount;
			 HoursCount=exitTime - (carPointer[i].getEntryTime());
			 amountCollected+=(20*HoursCount);
			 carPointer[i].setRegNo("");
			 carPointer[i].setEntryTime(0);
			 carPointer[i].setExiteTime(0);
			 noOfOccupied--;
		 }
	 }
	 return amountCollected;
 }
